import { injectReducer } from '../../store/reducers'
import course from './components/Course'
export default (store) => ({
  path: 'course',
 component: course
})

import React, { Component } from 'react'
import { Row, Col, Icon, Input, Button, message } from 'antd'
import '../css/courseqa.scss'
import { browserHistory } from 'react-router'
import { POST1, BASE_URL } from '../../../../components/commonModules/POST'
import moment from 'moment'
const { TextArea } = Input

export default class Courseqa extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      likecount:0,
      result:true,
      like:false,
      answer:'',
      text:''
    }
  }
  changeres () {
    this.setState({ result:false })
  }
  changevalue (e) {
    this.setState({ answer:e.target.value })
  }

  // 回答问题的接口
  submit () {
    var text = this.state.answer
    var id = this.props.data.id
    var cid = this.props.data.cid
    var data = `data=${text}&qid=${id}&cid=${cid}`
    POST1('/user/createQuestion.action', data, (re) => {
      if (re.status == 1) {
        message.success('回答成功')
        this.setState({ answer:'' })
        this.refs.getanswer.getQuestion()
      } else {
        message.error('网络错误 ，请稍后再试')
      }
    })
  }
  render () {
    const ppid=this.props.pid
    const qqid=this.props.qid
    const ccid=this.props.cid
    const { data, startedDate, pid, id } = this.props.data
    const { head, account } = this.props.data.user
    return (
      <div className='course-qa' >
        <Row>
          <Col span={2} >
            <div className='header-container'>
              <img src={BASE_URL + head} height='35px' width='35px' />{this.state.result == false
            ? <Icon type='question-circle-o' className='icon-ques-revert' /> : <Icon type='check-circle' className='icon-ques-true' />}
            </div>
          </Col>
          <Col span={18} offset={1}>
            <div className='qa-content'>
              <a href='' className='user-name' >{account}</a>
              <a href=''><h3 className='qa-title'>{data}</h3></a>
              <Answer 
                id={id} 
                changeres={this.changeres.bind(this)} 
                answer={this.state.answer} 
                ref='getanswer'
                pid={ppid}
                qid={qqid}
                cid={ccid} /><br />
              <TextArea placeholder='请输入你的答案' cols={15} rows={2} style={{ display:'inline-block',width:450 }}
                onChange={this.changevalue.bind(this)} value={this.state.answer} />
              <Button style={{ display:'inline-block', marginLeft: 390, marginTop:5 }} onClick={this.submit.bind(this)}>提交</Button>
              <div className='qa-time'>时间：{moment(startedDate).format('YYYY-MM-DD')}</div>
            </div>
          </Col>
        </Row>
      </div>
    )
  }
}

// 问题的回答列表
class Answer extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      anslist:[] // 回复列表
    }
  }
  // 获取问答列表
  componentWillMount () {
    this.getQuestion()
  }
  // 将获取问答放到方法中
  getQuestion () {
    let qid = this.props.qid
    let pid = this.props.pid
    let cid=this.props.cid
    console.log(typeof(qid),pid,cid)
    if(!typeof(qid)===undefined){
    var data = `qid=${qid}`}
    else if(!typeof(pid)===undefined){
      var data=`pid=${pid}`
    }else{
      var data=`cid=${cid}`
    }
    console.log(data)
    POST1('/getQuestion.action', data, (re) => {
      if (re.status == 1) {
        this.setState({ anslist:re.data })
        if (re.data.length <= 0) {
          this.props.changeres()
        }
      }
    })
  }

  render () {
    console.log(this.props.id)
    return (
      <div style={{ marginLeft:10, marginTop:5 }}>
        {
        this.state.anslist.length > 0 ? <div style={{ marginLeft:15 }}>{this.state.anslist.map((item, i) => {
          return (<span key={i}>
            <span style={{ fontSize:12 }}>{item.user.account}:</span>
            <p style={{ display:'inline-block', fontSize:12,color:'#93999f' }}>{item.data}</p><br />
          </span>
          )
        })}</div> : <span style={{fontSize:12,marginLeft:15,color:'#93999f'}}>暂无问答</span>
      }
      </div>
    )
  }
}

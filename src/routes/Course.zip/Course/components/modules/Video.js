import React, { Component } from 'react'
export default class Video extends Component {
  render () {
    return (
      <div className='video' style={{ border:'1px solid red' }}>
        <video width='500' height='500' controls='controls' autoPlay='autoplay'>
          <source src='/i/movie.ogg' type='video/ogg' />
          <source src='/i/movie.mp4' type='video/mp4' />
          <source src='/i/movie.webm' type='video/webm' />
          <object data='/i/movie.mp4' width='320' height='240'>
            <embed width='320' height='240' src='Wildlife.wmv' />
          </object>
        </video>
      </div>
    )
  }
}
